var canvas=document.querySelector("canvas");

canvas.width=window.innerWidth;
canvas.height=window.innerHeight;

var c=canvas.getContext("2d");

/*c.fillStyle= "#0000C2";
c.fillRect(60, 60, 100, 55);

c.fillStyle= "#000000";
c.fillRect(100, 100, 60, 53);

c.fillStyle= "#00E400";
c.fillRect(85, 100, 55, 70);

c.fillStyle= "#ff00ff";
c.fillRect(60, 130, 85, 62);


c.beginPath();
c.moveTo(50, 50);
c.lineTo(265, 265);
c.strokeStyle="rgba(255,255,255,1)";
c.stroke();

for(var i=0; i<200; i++) {
c.fillStyle="rgba("+Math.floor(Math.random()*256)+","+Math.floor(Math.random()*256)+","+Math.floor(Math.random()*256)+",1)";
c.fillRect(Math.floor(Math.random()*159),Math.floor(Math.random()*211),Math.floor(Math.random()*1000),Math.floor(Math.random()*500));
}\

c.beginPath();
c.arc(300, 300, 30, 0, Math.PI*2, false)
c.strokeStyle="FFFFFF"
c.stroke();
*/
var xPosition=200;
var xRate=1;
var radius=30;

function animate() {
    requestAnimationFrame(animate);
    c.clearRect(0,0,window.innerWidth, window.innerHeight)
    c.beginPath();
    //radius=Math.random()*5+10;
    c.arc(xPosition,200,radius,0,Math.PI*2,false);
    c.fillStyle="#FFFFFF";
    //c.fillStyle="rgba("+Math.floor(Math.random()*256)+","+Math.floor(Math.random()*256)+","+Math.floor(Math.random()*256)+",1)";
    c.fill();
    
    if(xPosition+radius>window.innerWidth) {
    xRate=-xRate;
    }
    if(xPosition-radius<0) {
        xRate=-xRate;
    }
    xPosition+=xRate;
    
}


animate();